details = {'Tom': {"Name": "Tom", "Roll no": "l401", "Address": "2 red street", "Dept": "ECE"},
           "Sam": {"Name": "Sam", "Roll no": "l402", "Address": "3 green street", "Dept": "IT"}}
print(details["Tom"])
print(details["Tom"]["Dept"])
import json
s=json.dumps(details)
"""dictionary to string"""
print(s)
print(type(s))
d=json.loads(s)
"""string to dictionary"""
print(d)
print(type(d))
print(dir(json))
"""to view available methods in module"""
