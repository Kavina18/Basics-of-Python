a = int(input("Enter num 1 :"))
b = int(input("Enter num 2 :"))
try:
    div = a/b
except Exception as e:
    print(f"{e} Exception")
    #div = "infinite"
print(f"Division of {a} and {b} is infinite")
#print(f"Division of {a} and {b} is {div}")
