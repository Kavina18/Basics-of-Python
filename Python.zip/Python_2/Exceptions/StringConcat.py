a = input("Input 1 : ")
b = int(input("Input 2 : "))
"""c = a + b
print(c)"""
try:
    c = a + b
except Exception as e:
    print(f"{e} Exception")
    c = None
print(c)

