def add(a,b):
    # document string
    """
    this function takes two integer inputs and return sum of the inputs
    """
    sum=a+b
    return sum


input1=int(input("Enter num 1:"))
input2=int(input("Enter num 2:"))
# input1=(input("Enter num 1:"))
# input2=(input("Enter num 2:"))
# result=add(int(input1),int(input2))
result=add(input1,input2)
print(f"The Sum is {result}")