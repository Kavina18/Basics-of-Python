import calculator
result=calculator.add(10,2)
print("Sum is",result)
result=calculator.sub(10,2)
print(f"Sub is {result}")
result=calculator.mul(10,2)
print(f"mul is {result}")
result=calculator.div(10,2)
print(f"div is {result}")
result=calculator.mod(10,2)
print(f"mod is {result}")
print(dir(calculator))
"""import calculator as calc
res=calc.add(10,2)
print(f"Sum is {res}")"""


