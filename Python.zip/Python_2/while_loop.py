exp = [2000, 3000, 4000, 5000, 2000, 1500]
i = 0
total = 0
while i < len(exp):
    total = total + exp[i]
    i = i + 1
print("Total expense is :", total)
