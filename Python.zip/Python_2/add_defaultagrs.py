def add(a,c,b=6):
    # document string
    """

    :param a: integer input
    :param c:integer input
    :param b:integer input
    :return:integer sum
    """
    sum=a+b+c
    return sum


input1=int(input("Enter num 1:"))
input2=int(input("Enter num 2:"))
result=add(input1,input2)
# result=add(input1,input2,10)  #default value of b=6 changed to 10
print(f"The Sum is {result}")