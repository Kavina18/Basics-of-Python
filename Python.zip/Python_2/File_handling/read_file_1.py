with open("D://python_file_handling//input1.txt","r") as fr:
    s=fr.read()
    print(s)