with open("input1.txt", "r") as fr:
    s=fr.read()
    print(s)
# print(s)
