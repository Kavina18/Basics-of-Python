content = input("Enter the content to write in file:")
# with open("input1.txt", "w") as f:
f=open("input1.txt", "w")
f.write(content)
print("Wrote successfully")
f.close()