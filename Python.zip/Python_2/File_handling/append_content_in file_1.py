content=" welcome to python"
with open("D://python_file_handling//input1.txt","a") as fa:
    fa.write(content)
    print("appended")