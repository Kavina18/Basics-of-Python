content = '''hello everyone
hello all
welcome'''
f=open("input1.txt", "w")
f.write(content)
print("Wrote successfully")
f.close()