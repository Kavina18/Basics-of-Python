content=" welcome to python"
with open("input1.txt", "a") as fa:
    fa.write(content)
    print("appended")
# print("aaaaaa")
