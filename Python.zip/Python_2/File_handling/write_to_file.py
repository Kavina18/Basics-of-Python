content = input("Enter the content to write in file:")
# f=open("D://python_file_handling//input1.txt","w")
with open("D://python_file_handling//input1.txt", "w") as f:
    f.write(content)
    print("Wrote successfully")
