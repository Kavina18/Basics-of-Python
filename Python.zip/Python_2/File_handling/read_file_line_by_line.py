
i=1
with open("input1.txt","r") as fr:
    for a in fr:
        print("line",i)
        print(a)
        i=i+1