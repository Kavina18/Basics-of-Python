class Students:
    def __init__(self, name, dept, cgpa):
        self.name = name
        self.dept = dept
        self.cgpa = cgpa

    def setcgpa(self, cgpa):
        self.cgpa = cgpa

    def display(self):
        print(f"Name={self.name}\nDept={self.dept}\nCGPA={self.cgpa}")

    def getname(self):
        return self.name


if __name__ == "__main__":
    name="Kavina"
    S1 = Students(name, "ECE", 9.03)
    S2 = Students("Kavin", "ECE", 9.01)
    S1.setcgpa(9.05)
    S1.display()
    S1n = S1.getname()
    print("Name =", S1n)
    S2.display()
    S2n = S2.getname()
    print("Name =", S2n)
