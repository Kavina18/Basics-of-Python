def calculate_total(exp):
    total = 0
    for x in range(0, len(exp)):
        total = total + exp[x]
    return total


tom = [1000, 1000, 1000]
joe = [2000, 2000, 2000, 3000]
tom_result = calculate_total(tom)
joe_result = calculate_total(joe)
print("TOM :", tom_result)
print("JOE :", joe_result)
# print("TOM :",calculate_total(tom))
# print("JOE :",calculate_total(joe))
