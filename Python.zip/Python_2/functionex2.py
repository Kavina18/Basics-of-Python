def Happy_birthday(name):
    print("Happy birthday",name)


inputName=input("Enter a name:")
Happy_birthday(inputName)
Happy_birthday("sam")