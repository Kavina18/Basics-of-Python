def area_tri(b, h):
    return 1/2 * b * h


##if __name__ == "__main__":
a = area_tri(10, 20)
print(f"area : {a}")
