def area_rect(b, h):
    return b * h


if __name__ == "__main__":
    a = area_rect(10, 20)
    print(f"area : {a}")
