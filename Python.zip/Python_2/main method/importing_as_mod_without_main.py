import without_main as area
A=area.area_tri(5,10)
print("area :",A)