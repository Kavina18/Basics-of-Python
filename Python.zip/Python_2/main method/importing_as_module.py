import area_of_rectangle as area
A=area.area_rect(5,10)
print("area :",A)