class Solution(object):
    def findMedianSortedArrays(self, nums1, nums2):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :rtype: float
        """
        nums1.extend(nums2)
        nums1.sort()
        l: int = len(nums1)
        if l % 2 != 0:
            median = float(nums1[int(l / 2)])
            return median
        else:
            mei1 = int(l / 2)
            mei2 = mei1 - 1
            median = float((int(nums1[mei1]) + int(nums1[mei2])) / 2)
            return median


if __name__ == "__main__":
    num1 = list(map(int, input().split()))
    num2 = list(map(int, input().split()))
    """num1.extend(num2)
    num1.sort()
    print(num1)"""
    f = Solution()
    result = f.findMedianSortedArrays(num1, num2)
    print(f"Median={result}")
