class Solution(object):
    def threeSum(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        nums.sort()
        rrnums = []
        for a in range(0, len(nums) - 2):
            for b in range(a + 1, len(nums) - 1):
                for c in range(b + 1, len(nums)):
                    if nums[a] + nums[b] + nums[c] == 0:
                        rnums = [nums[a], nums[b], nums[c]]
                        if rnums in rrnums:
                            continue
                        else:
                            rrnums.append(rnums)
        return rrnums


nums = list(map(int, input().split()))
t = Solution()
result = t.threeSum(nums)
print(result)
