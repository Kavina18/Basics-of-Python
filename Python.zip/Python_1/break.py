exp = [2500,2000,3000,2500,3500,2300,5000,2400,2300,6000,1200,3000]
total=0
# for only 6 months
for x in range(0,len(exp)):
    total=total+exp[x]
    print("month",x+1,"is",exp[x],"rupees")
    if x == 5:
        break
print('Total expense for 6 months is:',total)