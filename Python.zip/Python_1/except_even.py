print("square of number from 1 to 5 except even:")
for x in range(1,6):
    if x%2==0:
        continue
    else:
        print(x*x)
