fruits = ["apple","mango","banana"]
vegetables = ["beetroot","potato","carrot"]
junk_food = ["pizza","chips","burger"]
in1 = input("Enter the item:")
if in1 in fruits:
    print(in1, 'is fruit')
elif in1 in vegetables:
    print(in1, "is vegetable")
elif in1 in junk_food:
    print(in1, "is junk_food")
else:
    print("can't found")
