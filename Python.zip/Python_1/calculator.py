num1 = int(input("Enter 1st number:"))
num2 = int(input("Enter 2st number:"))
option = input("Enter the Operator to perform:")
if option == '+':
    ans = num1 + num2
    print(ans)
elif option == '-':
    ans = num1 - num2
    print(ans)
elif option == '*':
    ans = num1 * num2
    print(ans)
elif option == '/':
    ans = num1 / num2
    print(ans)
elif option == '%':
    ans = num1 % num2
    print(ans)
else:
    print("Invalid operator...")
