exp = [2500,2000,3000,2500,3500,2300,5000,2400,2300,6000,1200,3000]
total=0
#for x in exp:
    #total=total+x
for x in range(0,len(exp)):
    total = total + exp[x]
print('Total expense is:',total)