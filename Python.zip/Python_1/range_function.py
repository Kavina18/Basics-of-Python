for i in range(0,13):
    print(i)
